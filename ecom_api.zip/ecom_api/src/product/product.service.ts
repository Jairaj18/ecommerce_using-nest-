import { Injectable, ConflictException } from '@nestjs/common';
import { PrismaService } from 'src/prisma/prisma.service';
import { CreateProductDto } from './dto/create-product.dto';
import { Product } from '@prisma/client';

@Injectable()
export class ProductService {
  constructor(private readonly prisma: PrismaService) {}

  async createProduct(data: CreateProductDto): Promise<Product> {
    try {
      // Check if a product with the same name already exists
      const existingProduct = await this.prisma.product.findUnique({
        where: { name: data.name },
      });

      if (existingProduct) {
        throw new ConflictException('Product with this name already exists');
      }

      // Create the product if no conflict
      const createdProduct = await this.prisma.product.create({
        data,
      });

      return createdProduct;
    } catch (error) {
      // Handle unique constraint error
      if (error.code === 'P2002' && error.meta?.target.includes('name')) {
        throw new ConflictException('Product with this name already exists');
      }
      throw error;
    }
  }
}
