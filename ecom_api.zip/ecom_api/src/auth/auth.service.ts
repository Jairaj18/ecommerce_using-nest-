import { Injectable,UnauthorizedException } from '@nestjs/common';
import { JwtService } from '@nestjs/jwt';
import { UserService } from 'src/user/user.service';
import { AuthDto } from './dto/auth-credentials.dto';
import * as bcrypt from 'bcryptjs';
import { Role } from '@prisma/client';
import { Roles } from './role.decorator';

@Injectable()
export class AuthService {
    validateUser: any;
    constructor(
        private userService:UserService,
        private jwtService:JwtService,
    ){}

    async signUp(authDto: AuthDto, res: any): Promise<void> {
        const { email, password, name, address } = authDto;
        
        try {
            const user = await this.userService.createUser(email, password, name, address);
            return res.status(201).json({ message: 'Signup successful', user });
        } catch (error) {
            return res.status(400).json({ message: error.message });
        }
    }

    async signIn(authDto: AuthDto): Promise<{accessToken:string}>{
        const {email, password} = authDto;
        const user = await this.userService.findByEmail(email);
        if(user && (await bcrypt.compare(password,user.password))){
            const payload = {email, role:user.role};
            const accessToken = await this.jwtService.sign(payload);
            return{accessToken};
        }else{
            throw new UnauthorizedException('Invalid credential');
        }
    }
}
