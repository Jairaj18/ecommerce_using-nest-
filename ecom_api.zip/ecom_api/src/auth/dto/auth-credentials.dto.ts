
export class AuthDto{
    email: string;
    password: string;
    name: string;
    address?: string;
    role:String
}