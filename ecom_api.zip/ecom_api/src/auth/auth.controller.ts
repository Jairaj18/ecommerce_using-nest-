import { Body, Controller, Post, Req, Res } from '@nestjs/common';
import { AuthService } from './auth.service';
import { AuthDto } from './dto/auth-credentials.dto';

@Controller('auth')
export class AuthController {
    constructor(private authServise:AuthService){}

    @Post('/signup')
    async signUp(@Body() AuthDto:AuthDto , @Res() res): Promise<void>{
        console.log('inside api')
        return await this.authServise.signUp(AuthDto,res);
    }

    @Post('/signin')
    async  signIn(@Body() AuthDto:AuthDto): Promise<{accessToken: string}>{
        return this.authServise.signIn(AuthDto);

    }
}
